<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/order.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/template.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/sidebar.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/header.css') }}" />
</head>

<body>
  @component('template')
  @slot('content')
  <div class="order">
    <div class="order-list">
      <div class="order-list-title">Order Report</div>
      <div class="order-separator"></div>
      <div class="order-action">
        <div class="input-group order-action-search">
          <input type="text" class="form-control" aria-label="Search" aria-describedby="search">
          <button class="btn btn-secondary" type="button" id="search">Search</button>
        </div>
        <button type="button" class="btn btn-primary">
          Export to PDF
        </button>
      </div>
      <div class="order-list-table">
        <table class="table table-striped">
          <thead>
            <tr>
              <th class="order-head" scope="col">#</th>
              <th class="order-head" scope="col">Product</th>
              <th class="order-head" scope="col">Price</th>
              <th class="order-head" scope="col">Created At</th>
              <th class="order-head" scope="col">Status</th>
              <th class="order-head" scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach($orders as $o)
            <tr>
              <th class="order-row" scope="row"></th>
              <td class="order-row order-row-title">
                {{ $o->order_name }}
              </td>
              <td class="order-row">
                {{ $o->order_price }}
              </td>
              <td class="order-row">
                {{ $o->created_at }}
              </td>
              <td class="order-row">
                {{ $o->order_status }}
              </td>
              <td class="order-row-action">
                <button type="button" class="btn btn-warning">
                  <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button type="button" class="btn btn-danger">
                  <i class="fa-solid fa-trash-can"></i>
                </button>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
  @endslot
  @endcomponent
</body>

</html>
<div class="template">
  <div>
    @component('sidebar')
    @endcomponent
  </div>
  <div>
    <div class="template-header">
      @component('header')
      @endcomponent
    </div>
    <div class="template-content">
      {{ $content }}
    </div>
  </div>
</div>
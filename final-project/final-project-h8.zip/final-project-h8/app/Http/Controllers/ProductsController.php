<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;

class ProductsController extends Controller
{
    public function index()
    {
        $products = Products::latest()->get();

        return view('product', compact('products'));
    }

    public function create()
    {
        return view('new-product');
    }

    public function store(Request $request)
    // 'product_name', 'product_description', 'product_price', 'product_weight', 'product_status', 'product_image'
    {
        $this->validate($request, [
            'product_name' => 'required',
            'product_description' => 'required',
            'product_price' => 'required',
            'product_weight' => 'required',
            'product_status' => 'required',
            'product_image' => 'required',
        ]);

        $post = Products::create([
            'product_name' => $request->product_name,
            'product_description' => $request->product_description,
            'product_price' => $request->product_price,
            'product_description' => $request->product_description,
            'product_weight' => $request->product_weight,
            'product_status' => $request->product_status,
            'product_image' => $request->product_image,
        ]);

        if ($post) {
            return redirect()
                ->route('product.index')
                ->with([
                    'success' => 'New post has been created successfully'
                ]);
        } else {
            return redirect()
                ->route('product.index')
                ->with([
                    'error' => 'Some problem occurred, please try again'
                ]);
        }
    }

    public function destroy($id)
    {
        $post = Products::findOrFail($id);
        $post->delete();

        if ($post) {
            return redirect()
                ->route('product.index')
                ->with([
                    'success' => 'Post has been deleted successfully'
                ]);
        } else {
            return redirect()
                ->route('product.index')
                ->with([
                    'error' => 'Some problem has occurred, please try again'
                ]);
        }
    }
}

<div class="template">
  <div>
    <?php $__env->startComponent('sidebar'); ?>
    <?php echo $__env->renderComponent(); ?>
  </div>
  <div>
    <div class="template-header">
      <?php $__env->startComponent('header'); ?>
      <?php echo $__env->renderComponent(); ?>
    </div>
    <div class="template-content">
      <?php echo e($content); ?>

    </div>
  </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/brizky-final-project/resources/views/template.blade.php ENDPATH**/ ?>
<div class="header">
  <div class="header-top">
    <i class="fa-solid fa-bars"></i>
    <i class="fa-solid fa-user"></i>
  </div>
  <div class="header-bottom">
    <?php if(Request::segment(1) == 'dashboard'): ?>
    <div class="header-bottom-title">Dashboard</div>
    <div class="header-bottom-url">
      <span>Home</span> / Dashboard
    </div>
    <?php endif; ?>
    <?php if(Request::segment(1) == 'category'): ?>
    <div class="header-bottom-title">Category</div>
    <div class="header-bottom-url">
      <span>Home</span> / Category
    </div>
    <?php endif; ?>
    <?php if(Request::segment(1) == 'product' && Request::segment(2) == ''): ?>
    <div class="header-bottom-title">Product</div>
    <div class="header-bottom-url">
      <span>Home</span> / Product
    </div>
    <?php endif; ?>
    <?php if(Request::segment(1) == 'product' && Request::segment(2) == 'create'): ?>
    <a href="<?php echo e(url('product')); ?>" class="btn btn-secondary">
      Back
    </a>
    <div class="header-bottom-url">
      <span>Home</span> / <span>Product</span> / New Product
    </div>
    <?php endif; ?>
    <?php if(Request::segment(1) == 'order'): ?>
    <div class="header-bottom-title">Order</div>
    <div class="header-bottom-url">
      <span>Home</span> / Order
    </div>
    <?php endif; ?>
    <?php if(Request::segment(1) == 'report'): ?>
    <div class="header-bottom-title">Report</div>
    <div class="header-bottom-url">
      <span>Home</span> / Report
    </div>
    <?php endif; ?>
  </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/brizky-final-project/resources/views/header.blade.php ENDPATH**/ ?>
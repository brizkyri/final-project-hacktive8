<div class="sidebar">
  <div class="sidebar-title">
    <i class="fa-solid fa-user-lock"></i>
    <div class="sidebar-title-text">AdminLTE</div>
  </div>
  <div class="sidebar-separator"></div>
  <div class="sidebar-user">
    <i class="fa-regular fa-circle-user"></i>
    <div class="sidebar-user-text">Brizky</div>
  </div>
  <div class="sidebar-separator"></div>
  <div class="<?php echo e(Request::path() ==  'dashboard' ? 'sidebar-wrapper sidebar-active' : 'sidebar-wrapper'); ?>">
    <a class="sidebar-menu" href="<?php echo e(url('dashboard')); ?>">
      <i class="fa-solid fa-table-columns"></i>
      <div class="sidebar-menu-text">Dashboard</div>
    </a>
  </div>
  <div class="sidebar-contents">
    <div class="sidebar-content-title">Product Management</div>
    <div class="<?php echo e(Request::path() ==  'category' ? 'sidebar-active' : ''); ?>">
      <a class="sidebar-content" href="<?php echo e(url('category')); ?>">
        <i class="fa-solid fa-table-list"></i>
        <div class="sidebar-content-text">Category</div>
      </a>
    </div>
    <div class="<?php echo e(Request::path() ==  'product' ? 'sidebar-active' : ''); ?>">
      <a class="sidebar-content" href="<?php echo e(url('product')); ?>">
        <i class="fa-solid fa-box"></i>
        <div class="sidebar-content-text">Product</div>
      </a>
    </div>
    <div class="<?php echo e(Request::path() ==  'order' ? 'sidebar-active' : ''); ?>">
      <a class="sidebar-content" href="<?php echo e(url('order')); ?>">
        <i class="fa-solid fa-cart-shopping"></i>
        <div class="sidebar-content-text">Order</div>
      </a>
    </div>
    <div class="<?php echo e(Request::path() ==  'report' ? 'sidebar-active' : ''); ?>">
      <a class="sidebar-content" href="<?php echo e(url('report')); ?>">
        <i class="fa-solid fa-file-lines"></i>
        <div class="sidebar-menu-text">Report</div>
      </a>
    </div>
  </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/brizky-final-project/resources/views/sidebar.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/product.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/template.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/sidebar.css')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/header.css')); ?>" />
</head>

<body>
  <?php $__env->startComponent('template'); ?>
  <?php $__env->slot('content'); ?>
  <div class="product">
    <div class="product-list">
      <div class="product-list-title">Product List</div>
      <div class="product-separator"></div>
      <div class="product-action">
        <div class="product-action-left">
          <button type="button" class="btn btn-danger">
            Mass Upload
          </button>
          <a class="btn btn-primary" href="<?php echo e(route('product.create')); ?>">
            Add
          </a>
        </div>
        <div class="product-action-rigth">
          <div class="input-group mb-3">
            <input type="text" class="form-control" aria-label="Search" aria-describedby="search">
            <button class="btn btn-secondary" type="button" id="search">Search</button>
          </div>
        </div>
      </div>
      <div class="product-list-table">
        <table class="table table-striped">
          <thead>
            <tr>
              <th class="product-head" scope="col">#</th>
              <th class="product-head" scope="col">Product</th>
              <th class="product-head" scope="col">Price</th>
              <th class="product-head" scope="col">Weight</th>
              <th class="product-head" scope="col">Created At</th>
              <th class="product-head" scope="col">Status</th>
              <th class="product-head" scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <th class="product-row" scope="row"></th>
              <td class="product-row product-row-title">
                <?php echo e($p->product_name); ?>

              </td>
              <td class="product-row">
                <?php echo e($p->product_price); ?>

              </td>
              <td class="product-row">
                <?php echo e($p->product_weight); ?>

              </td>
              <td class="product-row">
                <?php echo e($p->created_at); ?>

              </td>
              <td class="product-row">
                <?php echo e($p->product_status); ?>

              </td>
              <td class="product-row-action">
                <form action="<?php echo e(route('product.destroy', $p->id)); ?>" method="POST">
                  <a class="btn btn-warning">
                    <i class="fa-solid fa-pen-to-square"></i>
                  </a>
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger">
                    <i class="fa-solid fa-trash-can"></i>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="product-row">
              <td class="text-center text-mute" colspan="7">
                Data not available
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php $__env->endSlot(); ?>
  <?php echo $__env->renderComponent(); ?>
</body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/brizky-final-project/resources/views/product.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/category.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/template.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/sidebar.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/header.css') }}" />
</head>

<body>
  @component('template')
  @slot('content')
  <div class="category">
    <div class="category-container">
      <div class="category-form">
        <div class="category-form-title">New Cateogry</div>
        <div class="category-separator"></div>
        <form action="{{ route('category.store') }}" method="POST">
          @csrf
          <div class="form-group category-input">
            <label for="category_name">Category Name</label>
            <input id="category_name" name="category_name" type="text" class="form-control" />
          </div>
          <div class="form-group category-input">
            <label for="category">Category Parent</label>
            <select class="form-select" name="category_parent">
              <option value="" selected>Selected</option>
              <option value="One">One</option>
              <option value="Two">Two</option>
              <option value="Three">Three</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Add</button>
        </form>
      </div>
      <div class="category-list">
        <div class="category-list-title">New List</div>
        <div class="category-separator"></div>
        <div class="categpry-list-table">
          <table class="table table-striped">
            <thead>
              <tr>
                <th class="category-head" scope="col">#</th>
                <th class="category-head" scope="col">Category</th>
                <th class="category-head" scope="col">Category Parent</th>
                <th class="category-head" scope="col">Created At</th>
                <th class="category-head" scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              @forelse ($categories as $c)
              <tr>
                <th class="category-row" scope="row"></th>
                <td class="category-row category-row-title">
                  {{ $c->category_name }}
                </td>
                <td class="category-row">
                  {{ $c->category_parent }}
                </td>
                <td class="category-row">
                  {{ $c->created_at }}
                </td>
                <td class="category-row-action">
                  <form action="{{ route('category.destroy', $c->id) }}" method="POST">
                    <a class="btn btn-warning">
                      <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">
                      <i class="fa-solid fa-trash-can"></i>
                    </button>
                  </form>
                </td>
              </tr>
              @empty
              <tr class="category-row">
                <td class="text-center text-mute" colspan="6">
                  Data not available
                </td>
              </tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  @endslot
  @endcomponent
</body>

</html>
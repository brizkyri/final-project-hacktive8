<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/new-product.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/template.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/sidebar.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/header.css') }}" />
</head>

<body>
  @component('template')
  @slot('content')
  <div class="new-product">
    <form class="new-product-container" action="{{ route('product.store') }}" method="POST">
      @csrf
      <div class="new-product-form">
        <div class="new-product-form-title">Add New Product</div>
        <div class="new-product-separator"></div>
        <div class="new-product-form-container">
          <div class="form-group new-product-input">
            <label for="product_name">Name</label>
            <input id="product_name" name="product_name" type="text" class="form-control" />
          </div>
          <div class="form-group new-product-input">
            <label for="description">Description</label>
            <textarea class="form-control" id="product_description" name="product_description" rows="11"></textarea>
          </div>
        </div>
      </div>
      <div class="new-product-form new-product-form-right">
        <div class="new-product-form-container">
          <div class="form-group new-product-input">
            <label for="new-product">Status</label>
            <select class="form-select" name="product_status">
              <option value="" selected>Selected</option>
              <option value="1">One</option>
              <option value="2">Two</option>
            </select>
          </div>
          <div class="form-group new-product-input">
            <label for="new-product">Category</label>
            <select class="form-select" name="product_category">
              <option value="" selected>Selected</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="form-group new-product-input">
            <label for="price">Price</label>
            <input id="product_price" name="product_price" type="text" class="form-control" />
          </div>
          <div class="form-group new-product-input">
            <label for="weight">Weight</label>
            <input id="product_weight" name="product_weight" type="text" class="form-control" />
          </div>
          <div class="form-group new-product-input">
            <label for="image" class="form-label">Image</label>
            <input class="form-control" name="product_image" type="text" id="product_image">
          </div>
          <div class="new-product-action">
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </div>
      </div>
  </div>
  </div>
  @endslot
  @endcomponent
</body>

</html>
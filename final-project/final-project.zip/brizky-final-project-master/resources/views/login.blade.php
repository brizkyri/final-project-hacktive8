<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/login.css') }}" />
</head>

<body class="login">
  <div class="container w-25">
    <div class="login-title">E-COMMERCE</div>
    <form class="login-form">
      <div class="input-group login-input">
        <input type="email" class="form-control" placeholder="Email" />
        <i class="fas fa-envelope ms-3"></i>
      </div>
      <div class="input-group login-input">
        <input type="password" class="form-control" placeholder="Password" />
        <i class="fas fa-lock ms-3"></i>
      </div>
      <div class="login-action">
        <a href="#">I forgot my password</a>
        <button type="submit" class="btn btn-primary">Sign In</button>
      </div>
    </form>
  </div>
</body>

</html>
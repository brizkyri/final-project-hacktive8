<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Final Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/dashboard.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/template.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/sidebar.css') }}" />
  <link rel="stylesheet" type="text/css" href="{{ url('assets/css/header.css') }}" />
</head>

<body>
  @component('template')
  @slot('content')
  <div class="dashboard">
    <div class="dashboard-container">
      <div class="dashboard-title">
        <i class="fa-solid fa-globe"></i>
        <div>Store Activity</div>
      </div>
      <div class="dashboard-separator"></div>
      <div class="dashboard-contents">
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">Rp 1</div>
            <div class="dashboard-left-title">Overall Revenue</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-coins"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">1</div>
            <div class="dashboard-left-title">Customer</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-user-group"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">2</div>
            <div class="dashboard-left-title">Product Category</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-list"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">3</div>
            <div class="dashboard-left-title">Product</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-tag"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">4</div>
            <div class="dashboard-left-title">New Order</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-envelope"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">5</div>
            <div class="dashboard-left-title">Order In Progress</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-people-carry-box"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">6</div>
            <div class="dashboard-left-title">Order In Delivery</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-truck-moving"></i>
          </div>
        </div>
        <div class="dashboard-content">
          <div class="dashboard-left">
            <div class="dashboard-left-amount">7</div>
            <div class="dashboard-left-title">Order Completed</div>
          </div>
          <div class="dashboard-right">
            <i class="fa-solid fa-hands-holding"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endslot
  @endcomponent
</body>

</html>
<?php

namespace App\Http\Controllers;

use App\Models\Categories;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    public function index()
    {
        $categories = Categories::latest()->get();
        return view('category', compact('categories'));
    }

    public function create()
    {
        return view('category');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'category_name' => 'required',
            'category_parent' => 'required'
        ]);

        $post = Categories::create([
            'category_name' => $request->category_name,
            'category_parent' => $request->category_parent
        ]);

        if ($post) {
            return redirect()
                ->route('category.index')
                ->with([
                    'success' => 'New post has been created successfully'
                ]);
        } else {
            return redirect()
                ->route('category.index')
                ->with([
                    'error' => 'Some problem occurred, please try again'
                ]);
        }
    }

    public function destroy($id)
    {
        $post = Categories::findOrFail($id);
        $post->delete();

        if ($post) {
            return redirect()
                ->route('category.index')
                ->with([
                    'success' => 'Post has been deleted successfully'
                ]);
        } else {
            return redirect()
                ->route('category.index')
                ->with([
                    'error' => 'Some problem has occurred, please try again'
                ]);
        }
    }
}
